import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_app_http/models/posts.dart';
import 'package:http/http.dart' as http;

class PostList extends StatefulWidget {
  const PostList({super.key});

  @override
  State<PostList> createState() => _PostListState();
}

class _PostListState extends State<PostList> {
  late Future<List<PostModel>> _postsFuture;
  @override
  void initState() {
    super.initState();
    _postsFuture = fetchPosts();
  }

  Future<List<PostModel>> fetchPosts() async {
    final url = Uri.parse('https://jsonplaceholder.typicode.com/posts');
    final response = await http.get(url);
    if(response.statusCode == 200){
      List<dynamic> jsonData = jsonDecode(response.body);
      return jsonData.map((json) => PostModel.fromJson(json)).toList();
    } else {
      throw Exception('Failed to fetch posts');
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(future: _postsFuture, builder: ( context, snapshot) {  
      if(snapshot.connectionState == ConnectionState.waiting){
        return const Center(child: CircularProgressIndicator());
      } else if(snapshot.hasError){
        return Center(child: Text('Error: ${snapshot.error}'));
      } else if(snapshot.hasData){
        final posts = snapshot.data as List<PostModel>;
        return ListView.builder(
          itemCount: posts.length,
          itemBuilder: (context, index) {
            final post = posts[index];
            return ListTile(
              title: Text(post.title),
              subtitle: Text(post.body),
            );
          },
        );
      } else {
        return const Center(child: Text('No data available'));
      }
    });
  }
}
